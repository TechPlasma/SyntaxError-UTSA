import { Component, OnInit } from '@angular/core';
import { IDForms } from '../idForms';

@Component({
  selector: 'app-idForms',
  templateUrl: './idForms.component.html',
  styleUrls: ['./idForms.component.css']
})
export class idFormsComponent implements OnInit {
  /*
  hero = 'Windstorm';
  */
  idForms: IDForms = {
    First: '',
    Last: '',
    Suffix: '',
    middleInitial:'',
    jobStatus: '',
    workPhone: '',
    jobTitle: '',
    department: '',
    SAP: '',
    Division: '',
    SupervisName: '',
    contactPhone: '',







  };

  constructor() { }

  ngOnInit() {
  }

}
