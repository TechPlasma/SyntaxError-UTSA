import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { idFormsComponent } from './idForms.component';

describe('idFormsComponent', () => {
  let component: idFormsComponent;
  let fixture: ComponentFixture<idFormsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ idFormsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(idFormsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
