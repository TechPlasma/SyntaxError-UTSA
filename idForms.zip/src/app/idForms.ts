export class IDForms {
  First: string;
  Last: string;
  middleInitial:string;
  Suffix:string;
  jobStatus:string;
  workPhone:string;
  jobTitle:string;
  department: string;
  SAP: string;
  Division: string;
  SupervisName:string;
  contactPhone : string;


}
